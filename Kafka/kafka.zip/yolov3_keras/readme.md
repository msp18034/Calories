Directly use the pre-trained model to do detection.

- Keras back-end
- the path configurations are in `yolo.py` 
- `yolo.py` will crop the input image to small images by each predicted bounding box
- code is adapted from https://github.com/qqwweee/keras-yolo3