import yolov3

yolov3.test()
